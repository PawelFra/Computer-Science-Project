﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    public class Player
    {
        Texture2D texture;

        public static Vector2 positionPlayer = new Vector2(100, 100);
        Vector2 velocity;

        public static Rectangle rectanglePlayer;

        bool Jumped = false;


        public void Load(ContentManager Content)
        {
            texture = Content.Load<Texture2D>("Gamer");
        }

        public void Update(GameTime gameTime)
        {
            
            positionPlayer += velocity;

            rectanglePlayer = new Rectangle((int)positionPlayer.X, (int)positionPlayer.Y, texture.Width, texture.Height);

            Movement();
            
        }

        private void Movement()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.A))
            {
                positionPlayer.X -= Stats.PlayersSpeed;
               
            }

            if (Keyboard.GetState().IsKeyDown(Keys.D))
            {
                positionPlayer.X += Stats.PlayersSpeed;
                
            }

            #region GravityHandling
            if (Keyboard.GetState().IsKeyDown(Keys.Space) && Jumped == false)
            {
                positionPlayer.Y -= 10f;
                velocity.Y = -5f;
                Jumped = true;
            }

            if (Jumped == true)
            {
                float i = 1;
                velocity.Y += 0.1f * i;
            }

            if (Jumped == false)
            {
                velocity.Y = 5f;
            }
            #endregion


        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectanglePlayer, Color.White);
        }

        public void Collision(Rectangle newRectangle, int Offx, int Offy)
        {
            if (rectanglePlayer.TouchTopOf(newRectangle))
            {
                rectanglePlayer.Y = newRectangle.Y - rectanglePlayer.Height;
                velocity.Y = 0f;
                Jumped = false;
            }

            if (positionPlayer.X < 0) positionPlayer.X = 0;
            if (positionPlayer.X > Offx - rectanglePlayer.Width) positionPlayer.X = Offx - rectanglePlayer.Width;
            if (positionPlayer.Y < 0) velocity.Y = 1f;
            if (positionPlayer.Y > Offy - rectanglePlayer.Height) positionPlayer.Y = Offy - rectanglePlayer.Height;

        }

        
    }

    public class PlayerHealth
    {
        Texture2D texture1;
        Texture2D texture2;
        Texture2D texture3;
        Texture2D texture4;

        Texture2D health;

        public static Vector2 healthPosition;
        public static Rectangle healthPositionRec;

        public static int healthCount = Stats.PlayersHealth;

        public void Load(ContentManager Content)
        {
            texture1 = Content.Load<Texture2D>("3Life");
            texture2 = Content.Load<Texture2D>("2Life");
            texture3 = Content.Load<Texture2D>("1Life");
            texture4 = Content.Load<Texture2D>("0Life");
        }

        public void Update()
        {
            if (healthCount == 3)
            {
                health = texture1;
            }
            else if(healthCount == 2)
            {
                health = texture2;
            }
            else if (healthCount == 1)
            {
                health = texture3;
            }
            else if (healthCount == 0)
            {
                health = texture4;
            }

            healthPosition = new Vector2(Player.positionPlayer.X, Player.positionPlayer.Y - 50);
            healthPositionRec = new Rectangle((int)healthPosition.X, (int)healthPosition.Y, health.Width, health.Height);


            if(Player.rectanglePlayer.Intersects(Enemy.EnemyRec) || Player.rectanglePlayer.Intersects(FlyingEnemy.flyingEnemyRec))
            {
                if(Stats.PlayersDefence < Stats.EnemiesAttack)
                {
                    healthCount = healthCount - 1;
                    Player.positionPlayer = new Vector2(100, 100);
                }
                else if (Stats.PlayersDefence == Stats.EnemiesAttack)
                {
                    Random rdnGen = new Random();
                    int randomNum = rdnGen.Next(0, 2);

                    if (randomNum == 2)
                    {
                        healthCount = healthCount - 1;
                        Player.positionPlayer = new Vector2(100, 100);
                    }
                    else
                    {
                        
                    }
                }
                else if (Stats.PlayersDefence > Stats.EnemiesAttack)
                {
                    Player.positionPlayer = new Vector2(100, 100);
                }
                
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(health, healthPositionRec, Color.White);
        }

    }
}
