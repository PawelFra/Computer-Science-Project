﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    public class Stats
    {
        #region Player_Stats
        public static int PlayersHealth = 3;
        public static int PlayersDefence = 1;
        public static int PlayersSpeed = 5;
        #endregion

        #region Enemies_Stats
        public static int EnemiesAttack = 2;
        public static int EnemiesSpeed = 3;
        #endregion
    }
}
