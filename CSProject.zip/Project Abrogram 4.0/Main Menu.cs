﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    class Main_Menu
    {
        Texture2D texture;
        Texture2D texture2;

        public static Rectangle Start;

        public static bool GameStarted = false;
        
            

        public void Load(ContentManager Content)
        {
            texture = Content.Load<Texture2D>("MainMenu");
            texture2 = Content.Load<Texture2D>("OffMainMenu");
        }

        public void Update()
        {
            Start = new Rectangle(0, 0, texture.Width, texture.Height);

            if(Keyboard.GetState().IsKeyDown(Keys.M))
            {
                GameStarted = true;
                texture = texture2;
            }

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, Start, Color.White);
        }
    }
}
