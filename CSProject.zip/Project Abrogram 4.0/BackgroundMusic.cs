﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4._0
{
    class BackgroundMusic
    {
        protected Song song;

        public void Load(ContentManager Content)
        {
            song = Content.Load<Song>("DoomMusic");
        }

        public void Update()
        {
            MediaPlayer.Play(song);
        }

        
    }
}
