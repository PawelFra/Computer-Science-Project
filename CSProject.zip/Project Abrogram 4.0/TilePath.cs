﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    class TilePath
    {

        public int boundX;
        public int boundY;
        public int boundWidth;
        public int boundHeight;

        public TilePath(int intX, int intY, int width, int height)
        {

            boundX = intX;
            boundY = intY;
            boundWidth = width;
            boundHeight = height;


        }
    }
}
