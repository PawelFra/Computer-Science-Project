﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Project_Abrogram_4
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        List<Enemy> enemies = new List<Enemy>();
        List<TilePath> TileGrid = new List<TilePath>();

        Texture2D texturePortal;

        #region GameSpriteInitialization
        Main_Menu mainMenu;
        Camera camera;
        TileMap map;
        Player player;
        NPC npc;
        Enemy enemy;
        FlyingEnemy flyingEnemy;
        PlayerHealth playerHealth;
        Score score;
        #endregion

        bool pathFound = true;
        public static bool canFollowPath = false;
        
        int timer = 1;
        int portalTimer = 0;
        Random rdnTileNum = new Random();
         
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            IsMouseVisible = true;

            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;

            graphics.ApplyChanges();
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            #region InitializeForSprites
            mainMenu = new Main_Menu();

            map = new TileMap();

            player = new Player();

            npc = new NPC();

            for(int i = 0; i < 1; i++)
            {
                enemy = new Enemy();
                enemies.Add(enemy);
            }

            flyingEnemy = new FlyingEnemy();

            playerHealth = new PlayerHealth();

            score = new Score();
            #endregion

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            camera = new Camera(GraphicsDevice.Viewport);

            Tiles.Content = Content;

            texturePortal = Content.Load<Texture2D>("Portal");

            map.Generate(new int[,]{
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,2,2,2,0,0,2,2,2,2,2,0,0,2,2,0,0,2,2,2,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,2,2,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,2,2,2,0,0,2,2,2,0,0,2,2,2,0,0,2,2,2,0,0,2,2,2,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            }, 64);

            #region LoadForSprites
            mainMenu.Load(Content);

            player.Load(Content);

            npc.Load(Content);

            foreach(var enemies in enemies)
            {
                enemies.Load(Content);
            }

            flyingEnemy.Load(Content);

            playerHealth.Load(Content);

            score.Load(Content);
            #endregion

            base.LoadContent();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if(PlayerHealth.healthCount == 0)
            {
                Exit();
            }

            portalTimer += 1;
            mainMenu.Update();

            if (Main_Menu.GameStarted == true)
            {
                #region UpdatesForSprites
                

                player.Update(gameTime);

                npc.Update();

                foreach (var enemies in enemies)
                {
                    enemies.Update(gameTime);
                }

                flyingEnemy.Update();

                playerHealth.Update();

                score.Update();

                foreach (CollisionTiles tile in map.CollisionTiles)
                {
                    player.Collision(tile.Rectangle, map.Width, map.Height);
                    npc.Collision(tile.Rectangle, map.Width, map.Height);
                    foreach (var enemies in enemies)
                    {
                        enemies.Collision(tile.Rectangle, map.Width, map.Height);
                    }
                    camera.Update(Player.positionPlayer, map.Width, map.Height); ;

                }
                #endregion

                #region A*
                if (pathFound == true)
                {
                    Tiles.ShortestPath.Clear(); //Clears the path so that a new one does not collide 

                    var start = new Tiles(); //Creates a tile at which the A* starts at
                    var finish = new Tiles(); //Creates a tile at which the A* ends (has to reach)




                    start.boundY = (((int)FlyingEnemy.flyingEnemyPosition.Y + 10) / 20) * 20; //Creates the Y axis coordinate of the start tile

                    start.boundX = (((int)FlyingEnemy.flyingEnemyPosition.X + 10) / 20) * 20; //Creates the X axis coordinate of the start tile

                    finish.boundY = (((int)Player.positionPlayer.Y + 10) / 20) * 20; //Creates the Y axis coordinate of the end tile

                    finish.boundX = (((int)Player.positionPlayer.X + 10) / 20) * 20; //Creates the X axis coordinate of the end tile


                    start.SetDistance(finish.boundX, finish.boundY); //Sets distance for the path between the start tile and finishing trial

                    var activeTiles = new List<Tiles>(); //Creates a tiles that have to be visited to arrive at the end of algorithm
                    activeTiles.Add(start); //Adds the starting tile that have to be followed
                    var visitedTiles = new List<Tiles>(); //Creates a list for the tiles that have been visited so that the program doesn't go back through them and make the enemy follow the same path multiple times before arriving at the finish location




                    while (activeTiles.Any()) //While there are tiles to be visited (path to be made to the finish)
                    {
                        var checkTile = activeTiles.OrderBy(x => x.boundCostDistance).First(); //Orders the list so that the path is followed in order from start to finish

                        if (checkTile.boundX == finish.boundX && checkTile.boundY == finish.boundY) //Checks if the A* path have been generated so it reaches the finish
                        {
                            Console.WriteLine("We are at the destination!"); //Tell the user that it has created the A* successfully
                            var tile = checkTile; //Upload all "checkTile" into "tile" variable
                            Console.WriteLine("Retracing steps backwards..."); //Creates the path by retracing its movement
                            while (tile != null) //If "tile" variable is not 0
                            {
                                try
                                {

                                    Tiles.ShortestPath.Add(new TilePath(tile.boundX, tile.boundY, 20, 20)); //Add tiles to create a path which later will be followed 


                                }
                                catch (Exception e) //If an error occurs, catch the error
                                {
                                    Console.WriteLine(e); //Output the error
                                }
                                tile = tile.Parent; //Sets tile as "tile.Parent" (the next tile after the tile)

                            }

                            return; //Returns the code back to the top
                        }

                        visitedTiles.Add(checkTile); //Adds "checkTile" to the 
                        activeTiles.Remove(checkTile); //Removes the starting location as its already achieved by the sprite

                        var walkableTiles = GetWalkableTiles(checkTile, finish); //Sets variable "walkableTiles" into the path from start to finish

                        foreach (var walkableTile in walkableTiles)
                        {

                            if (visitedTiles.Any(x => x.boundX == walkableTile.boundX && x.boundY == walkableTile.boundY))
                                continue; //If the tile can be walked through it will continue to generate the path


                            if (activeTiles.Any(x => x.boundX == walkableTile.boundX && x.boundY == walkableTile.boundY)) //If the path has an obstacle on it it will generate a route around it
                            {
                                var existingTile = activeTiles.First(x => x.boundX == walkableTile.boundX && x.boundY == walkableTile.boundY);
                                if (existingTile.boundCostDistance > checkTile.boundCostDistance) //Check the existing tile for collision
                                {
                                    activeTiles.Remove(existingTile); //if yes, it will make a path around it
                                    activeTiles.Add(walkableTile);
                                }
                            }
                            else
                            {

                                activeTiles.Add(walkableTile); //if no obstacle is found, it will regenerate the path again.
                            }
                        }

                        canFollowPath = true; //allows the enemy to start following the path
                        pathFound = false; //Stops the A* from generating more paths that are not needed.

                    }


                    Console.WriteLine("No Path Found!");
                }


                if (FlyingEnemy.newpath == true)
                {
                    pathFound = true;
                    FlyingEnemy.newpath = false;
                }
                #endregion
            }

            
            

            

            base.Update(gameTime);
        }

        #region Walkable tiles
        private static List<Tiles> GetWalkableTiles(Tiles currentTile, Tiles targetTile)
        {

            var possibleTiles = new List<Tiles>();

            bool leftcheck = false;
            bool rightcheck = false;
            bool upcheck = false;
            bool downcheck = false;
            bool PlayerCheck = false;
            // need to check for player here
            Rectangle PlayerRectangle = new Rectangle((int)Player.positionPlayer.X, (int)Player.positionPlayer.Y, 40, 40);


            // do intersect check here instead so doesnt put clashing tile in 
            foreach (Boundaries BoundItem in Boundaries.BoundaryList)
            {

                Rectangle BoundaryCheck = new Rectangle(BoundItem.boundX, BoundItem.boundY, BoundItem.boundWidth, BoundItem.boundHeight);
                Rectangle TileCheckDown = new Rectangle(currentTile.boundX, currentTile.boundY - 20, 20, 20);
                Rectangle TileCheckUp = new Rectangle(currentTile.boundX, currentTile.boundY + 20, 20, 20);
                Rectangle TileCheckLeft = new Rectangle(currentTile.boundX - 20, currentTile.boundY, 20, 20);
                Rectangle TileCheckRight = new Rectangle(currentTile.boundX + 20, currentTile.boundY, 20, 20);

                if (BoundaryCheck.Intersects(PlayerRectangle))
                    PlayerCheck = true;

                if (BoundaryCheck.Intersects(TileCheckDown))
                    downcheck = true;

                if (BoundaryCheck.Intersects(TileCheckUp))
                    upcheck = true;

                if (BoundaryCheck.Intersects(TileCheckLeft))
                    leftcheck = true;

                if (BoundaryCheck.Intersects(TileCheckRight))
                    rightcheck = true;

            }
            if ((downcheck == false) && (PlayerCheck == false))
            {
                possibleTiles.Add(new Tiles { boundX = currentTile.boundX, boundY = currentTile.boundY - 20, Parent = currentTile, boundCost = currentTile.boundCost + 1 });
                Console.WriteLine(currentTile.boundX.ToString(), currentTile.boundY.ToString());
            }

            if ((upcheck == false) && (PlayerCheck == false))
                possibleTiles.Add(new Tiles { boundX = currentTile.boundX, boundY = currentTile.boundY + 20, Parent = currentTile, boundCost = currentTile.boundCost + 1 });

            if ((leftcheck == false) && (PlayerCheck == false))
                possibleTiles.Add(new Tiles { boundX = currentTile.boundX - 20, boundY = currentTile.boundY, Parent = currentTile, boundCost = currentTile.boundCost + 1 });

            if ((rightcheck == false) && (PlayerCheck == false))
                possibleTiles.Add(new Tiles { boundX = currentTile.boundX + 20, boundY = currentTile.boundY, Parent = currentTile, boundCost = currentTile.boundCost + 1 });



            possibleTiles.ForEach(tile => tile.SetDistance(targetTile.boundX, targetTile.boundY));

            var maxX = 1500;
            var maxY = 1000;



            return possibleTiles

            .Where(tile => tile.boundX >= 0 && tile.boundY <= maxX)
            .Where(tile => tile.boundY >= 0 && tile.boundY <= maxY)

            .ToList();
        }
        #endregion

        
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, null, null, null, null, camera.Transform);

            mainMenu.Draw(spriteBatch);

            if (Main_Menu.GameStarted == true)
            {
                #region DrawForSprites

                map.Draw(spriteBatch);

                player.Draw(spriteBatch);

                npc.Draw(spriteBatch);

                foreach (var enemies in enemies)
                {
                    enemies.Draw(spriteBatch);
                }

                flyingEnemy.Draw(spriteBatch);

                playerHealth.Draw(spriteBatch);

                score.Draw(spriteBatch);
                #endregion

                #region A*Draw
                Texture2D texture = new Texture2D(GraphicsDevice, 1, 1, false, SurfaceFormat.Color); //Creates texture for the line
                texture.SetData<Color>(new Color[] { Color.White });  //Sets the colour of the texture to white

                //display shortest path
                foreach (TilePath ShortP in Tiles.ShortestPath) //For each tile
                {
                    spriteBatch.Draw(texture, new Rectangle(ShortP.boundX, ShortP.boundY,
                        20, 20), Color.Blue * 0.3f); //Draw a line for each pointing to the finish
                }

                foreach (Boundaries drawBoundary in Boundaries.BoundaryList) //For each tile on the map
                {
                    spriteBatch.Draw(texture, new Rectangle(drawBoundary.boundX, drawBoundary.boundY,
                        drawBoundary.boundWidth, drawBoundary.boundHeight), Color.Blue * 0.3f); //Draw boundaries
                }
                #endregion
            }

            if(portalTimer == 100)
            {
                spriteBatch.Draw(texturePortal, new Vector2(100, 100), Color.White);
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }

    }
}
