﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    public class Enemy
    {
        static Random rdngen = new Random();

        Texture2D texture;
        
        public static Vector2 positionEnemy = new Vector2(rdngen.Next(0, 1000), rdngen.Next(1, 400));
        
        Vector2 velocity;
        
        public static Rectangle EnemyRec;
        public static Rectangle EnemyRec2;

        bool Jumped;

        int timer;

        public FSM enemy = new FSM();


        public void Load(ContentManager Content)
        {
            texture = Content.Load<Texture2D>("Enemy1");
            

        }

        public void Update(GameTime gameTime)
        {
            positionEnemy += velocity;

            EnemyRec = new Rectangle((int)positionEnemy.X, (int)positionEnemy.Y, texture.Width, texture.Height);
            

            if (Jumped == true)
            {
                float i = 1;
                velocity.Y += 0.1f * i;
            }

            if (Jumped == false)
            {
                velocity.Y = 5f;
            }

            Movement(); 

        }

        private void Movement()
        {
            if (Player.rectanglePlayer.Intersects(EnemyRec))
            {
                enemy.AttackState();
            }
            else
                enemy.PopStack();



            if (enemy.Enemystack.Peek().ToString() == "Roam")
            {
                timer = timer + 1;
                if (timer < 200)
                    velocity.X = 3f;
                else
                {
                    velocity.X = -3f;
                    if (timer == 400)
                        timer = 0;
                }
            }
            else if (enemy.Enemystack.Peek().ToString() == "Attack")
            {
                velocity.X = 0f;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, EnemyRec, Color.White);
            

        }

        public void Collision(Rectangle newRectangle, int Offx, int Offy)
        {
            if (EnemyRec.TouchTopOf(newRectangle))
            {
                EnemyRec.Y = newRectangle.Y - EnemyRec.Height;
                velocity.Y = 0f;
                Jumped = false;
            }

            if (positionEnemy.X < 0) positionEnemy.X = 0;
            if (positionEnemy.X > Offx - EnemyRec.Width) positionEnemy.X = Offx - EnemyRec.Width;
            if (positionEnemy.Y < 0) velocity.Y = 1f;
            if (positionEnemy.Y > Offy - EnemyRec.Height) positionEnemy.Y = Offy - EnemyRec.Height;

        }


    }


    public class FlyingEnemy
    {
        Texture2D texture;
        public static Vector2 flyingEnemyPosition = new Vector2(1000, 200);
        public static Rectangle flyingEnemyRec;

        #region A*EnemyVariables
        private float _timer;
        public Vector2 Direction;
        public float _rotation;
        public float _tempRotation;
        public float RotationVelocity = 5f;
        public float LinearVelocity = 5f;
        bool bRotate = false;
        bool bTravel = false;
        Vector2 distance;
        float Xdiff, Ydiff;
        int rotationDifferencedeg = 0;
        public int ListCounter;
        public Vector2 Origin;
        public static bool newpath = false;
        #endregion

        public void Load(ContentManager Content)
        {
            texture = Content.Load<Texture2D>("EnemyF");
        }

        public void Update()
        {
            Origin = new Vector2(texture.Width / 2, texture.Height / 2);
            flyingEnemyRec = new Rectangle((int)flyingEnemyPosition.X, (int)flyingEnemyPosition.Y, texture.Width, texture.Height);

            Direction = new Vector2((float)Math.Cos(_rotation), (float)Math.Sin(_rotation));

            #region Path follow

            if (Game1.canFollowPath == true) //If the path for the enemy was generated
            {
                ListCounter = Tiles.ShortestPath.Count - 1; //delete the starting tile
                bRotate = true; //set rotation to true to start following
                Game1.canFollowPath = false; //set to false to stop the program from generating more paths
            }

            if (bRotate == true || bTravel == true)
            {
                var ShortP = Tiles.ShortestPath[ListCounter];

                if (ListCounter != 0)
                {
                    ShortP = Tiles.ShortestPath[ListCounter - 1]; //delete the starting tile
                }

                distance.X = ShortP.boundX - flyingEnemyPosition.X; //Set the X axis distance needing to be travelled to reach the finish
                distance.Y = ShortP.boundY - flyingEnemyPosition.Y; // Set the Y axis distance needing to be travelled to reach the finish
                
                _tempRotation = (float)Math.Atan2(distance.Y, distance.X); //Set a temporary rotation that the enemy will use to rotate as he follows a linear path


                
                float rotationDifference = _rotation - _tempRotation; //calculate by how much he has to rotate

                
                if ((rotationDifference) > Math.PI)
                {
                    rotationDifference -= (float)Math.PI * 2;
                }
                if ((rotationDifference) < -Math.PI)
                {
                    rotationDifference += (float)Math.PI * 2;
                }

                //This code will rorate the sprite by how much in need to follow the path correctly
                rotationDifferencedeg = (int)(MathHelper.ToDegrees(rotationDifference));

                
                if ((rotationDifferencedeg < 0) && (bRotate == true))
                {
                    _rotation += MathHelper.ToRadians(RotationVelocity);
                    
                }
                else if ((rotationDifferencedeg > 0) && (bRotate == true))
                {
                    _rotation -= MathHelper.ToRadians(RotationVelocity);
                    
                }

                //More rotation calculations
                
                if ((rotationDifferencedeg == 0) && (bRotate == true))
                {
                    bTravel = true;
                    bRotate = false;
                    
                }

                //If the enemy is ready to travel in a straight line to follow the path calculated set "btravel" to true to allow him to follow it
                if (bTravel == true)
                {
                    flyingEnemyPosition += Direction * LinearVelocity; //Speed + position of the enemy that follows the path

                    Xdiff = ShortP.boundX - flyingEnemyPosition.X;

                    Ydiff = ShortP.boundY - flyingEnemyPosition.Y;

                    if (Xdiff < 0)
                        Xdiff *= -1;
                    if (Ydiff < 0)
                        Ydiff *= -1;

                    
                    if ((Xdiff) < 4)
                    {
                        if ((Ydiff) < 4)
                        {
                            bTravel = false;
                            bRotate = true;
                            ListCounter -= 1;
                            

                        }
                    }
                    
                    //Code above is to set a difference so that if the flying enemy is close to the player, the code wont run anymore as there is no path to generate as the enemy is already at players location

                    if (ListCounter == 0)
                    {
                        bTravel = false;
                        bRotate = false;
                        newpath = true;
                    }

                }
            }
            #endregion

            
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, flyingEnemyRec, Color.White);
        }

    }
}
