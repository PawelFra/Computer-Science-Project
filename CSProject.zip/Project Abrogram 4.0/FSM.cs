﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    public class FSM
    {
        public Stack NPCstack = new Stack();//Creates a stack for the NPC
        public Stack Enemystack = new Stack();//Creates a stack for the enemy
        public enum States { Roam, Run, Greet, Attack }; //Creates available states
        
        public FSM()//Class constructor
        {
            NPCstack.Push(States.Roam);
            Enemystack.Push(States.Roam);
            //Pushes Roam state onto a stack every second if its not on top
        }

        public void RunState()//Creates a public method that can be used in any class
        {
            if (NPCstack.Peek().ToString() == "Run") { }//Checks if Run state is at the top of the stack of the npc
            else
                NPCstack.Push(States.Run);//If not it will push the Run state onto a stack
            
            if (Enemystack.Peek().ToString() == "Run") { }//Checks if Run state is at the top of the stack of the enemy
            else
                Enemystack.Push(States.Run);//If not it will push the Run state onto a stack
        }

        public void GreetState()//Creates a public method that can be used in any class
        {
            if (NPCstack.Peek().ToString() == "Greet") { }//Checks if Greet state is at the top of the stack of the npc
            else
                NPCstack.Push(States.Greet);//If not it will push the Greet state onto a stack

            if (Enemystack.Peek().ToString() == "Greet") { }//Checks if Greet state is at the top of the stack of the enemy
            else
                Enemystack.Push(States.Greet);//If not it will push the Greet state onto a stack
        }

        public void AttackState()//Creates a public method that can be used in any class
        {
            if (Enemystack.Peek().ToString() == "Attack") { }//Checks if Attack state is at the top of the stack of the enemy
            else
                Enemystack.Push(States.Attack);//If not it will push the Attack state onto a stack
        }

        public void PopStack()//Creates a public method that can be used in any class
        {
            if (NPCstack.Count > 1)//If the number of items in the stack is greater than 1
                NPCstack.Pop();//Remove everything from the NPC stack
           
            if (Enemystack.Count > 1)//If the number of items in the stack is greater than 1
                Enemystack.Pop();//Remove everything from the NPC stack
        }
    }
}
