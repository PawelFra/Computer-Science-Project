﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    public class NPC
    {
        static Random rdngen = new Random();

        Texture2D texture;
        public static Vector2 positionNpc = new Vector2(rdngen.Next(0,1000), rdngen.Next(1,400));
        Vector2 velocity;

        public static Rectangle rectangleNPC;

        bool Jumped;

        int timer = 0;
        
        public FSM npc = new FSM();
        

        public void Load(ContentManager Content)
        {
            texture = Content.Load<Texture2D>("NPC");
        }
        
        public void Update()
        {
            positionNpc += velocity;

            rectangleNPC = new Rectangle((int)positionNpc.X, (int)positionNpc.Y, texture.Width, texture.Height);
            
            if (Jumped == true)
            {
                float i = 1;
                velocity.Y += 0.1f * i;
            }

            if (Jumped == false)
            {
                velocity.Y = 5f;
            }

            Movement();

        }

        private void Movement()
        {
            if (Player.rectanglePlayer.Intersects(rectangleNPC))
            {
                npc.GreetState();//Runs the method that will push the greet state onto a NPC stack
            }
            else
                npc.PopStack();//Remove everything from npc stack

            if (Enemy.EnemyRec.Intersects(rectangleNPC))
            {
                npc.RunState();//Runs the method that will push the run state onto a NPC stack
            }
            else
                npc.PopStack();//Remove everything from npc stack

            if (npc.NPCstack.Peek().ToString() == "Roam")//If the top of the stack says "Roam" (the roam state is at the top of the stack)
            {
                timer = timer + 1;//Adds 1 to the timer every second
                if (timer < 100)//If the timer == 100
                    velocity.X = 2f;//NPC walks right
                else
                {
                    velocity.X = -2f;//NPC walks left
                    if (timer == 200)
                        timer = 0;//Reset the timer so npc can go right and then left again
                }
            }

            if (npc.NPCstack.Peek().ToString() == "Greet")
            {
                velocity.X = 0f;
            }

            if(npc.NPCstack.Peek().ToString() == "Run")
            {
                timer = timer + 1;
                if (timer < 100)
                    velocity.X = 4f;
                else
                {
                    velocity.X = -4f;
                    if (timer == 200)
                        timer = 0;
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectangleNPC, Color.White);
        }

        public void Collision(Rectangle newRectangle, int Offx, int Offy)
        {
            if (rectangleNPC.TouchTopOf(newRectangle))
            {
                rectangleNPC.Y = newRectangle.Y - rectangleNPC.Height;
                velocity.Y = 0f;
                Jumped = false;
            }

            if (positionNpc.X < 0) positionNpc.X = 0;
            if (positionNpc.X > Offx - rectangleNPC.Width) positionNpc.X = Offx - rectangleNPC.Width;
            if (positionNpc.Y < 0) velocity.Y = 1f;
            if (positionNpc.Y > Offy - rectangleNPC.Height) positionNpc.Y = Offy - rectangleNPC.Height;

        }


    }
}
