﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    class Boundaries
    {
        public int boundX;
        public int boundY;
        public int boundWidth;
        public int boundHeight;
        Texture2D texture;

        public Vector2 Position;

        public static List<Boundaries> BoundaryList = new List<Boundaries>();

        public Boundaries(Rectangle rectangle, int intX, int intY, int width, int height)
        {

            boundX = intX;
            boundY = intY;
            boundWidth = width;
            boundHeight = height;

            
        }
    }
}
