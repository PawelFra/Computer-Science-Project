﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    class Tiles
    {
        protected Texture2D texture;

        private Rectangle rectangle;
        public Rectangle Rectangle
        {
            get { return rectangle; }
            protected set { rectangle = value; }
        }

        private static ContentManager content;
        public static ContentManager Content
        {
            protected get { return content; }
            set { content = value; }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectangle, Color.White);
        }

        public static List<TilePath> ShortestPath = new List<TilePath>();

        public int boundX;
        public int boundY;
        public int boundWidth;
        public int boundHeight;

        public int boundCost { get; set; }
        public int boundDistance { get; set; }
        public int boundCostDistance => boundCost + boundDistance;
        public Tiles Parent { get; set; }

        public void SetDistance(int targetX, int targetY)
        {
            this.boundDistance = Math.Abs(targetX - boundX) + Math.Abs(targetY - boundY);
        }



    }
}
