﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    public class Score
    {
        private SpriteFont font;
        public static int score;
        public static Vector2 scorePosition;


        public void Load(ContentManager Content)
        {
            font = Content.Load<SpriteFont>("Score");
        }

        public void Update()
        {
            scorePosition = new Vector2(Player.positionPlayer.X, Player.positionPlayer.Y + 75);
            score += 1;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.DrawString(font, "Score " + score, scorePosition, Color.Black);
        }

    }
}
