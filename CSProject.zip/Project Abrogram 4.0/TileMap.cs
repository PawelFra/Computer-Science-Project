﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Abrogram_4
{
    class TileMap
    {
        private List<CollisionTiles> collisionTiles = new List<CollisionTiles>();
        

        public List<CollisionTiles> CollisionTiles
        {
            get { return collisionTiles; }
        }

        private int width;
        private int height;

        public int Width
        {
            get { return width; }
        }

        public int Height
        {
            get { return height; }
        }

        public TileMap() { }

        
        public void Generate(int[,] tileMap, int size)
        {
            

            for (int x = 0; x < tileMap.GetLength(1); x++)
                for(int y = 0; y < tileMap.GetLength(0); y++)
                {
                    int number = tileMap[y, x];

                    if (number > 0)
                    {
                        Boundaries.BoundaryList.Add(new Boundaries(new Rectangle(), x * size, y * size, size, size));
                        collisionTiles.Add(new CollisionTiles(number, new Microsoft.Xna.Framework.Rectangle(x * size, y * size, size, size)));
                        
                    }
                       
                    width = (x + 1) * size;
                    height = (y + 1) * size;

                }

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (CollisionTiles tile in collisionTiles)
                tile.Draw(spriteBatch);
        }

    }

}
